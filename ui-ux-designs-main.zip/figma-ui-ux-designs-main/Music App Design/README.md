# MUSIC APP FIGMA DESIGN :
https://www.figma.com/file/x7vE5IVvEtPfC5TkEFJ53a/music?type=design&node-id=0%3A1&mode=design&t=T9DYsbqmY8sOvuuQ-1
