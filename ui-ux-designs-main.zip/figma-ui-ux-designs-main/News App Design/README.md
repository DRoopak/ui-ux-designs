# NEWS APP USING FIGMA
url:https://www.figma.com/file/EpEsoJDe33Sd0wdohwtCZV/news-app?type=design&node-id=0%3A1&mode=design&t=WXqYagPv6YrcF2s5-1
